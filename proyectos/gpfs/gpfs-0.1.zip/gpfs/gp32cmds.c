#include <ctype.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <libgen.h>
#include <fcntl.h>

#include "usb_drv.h"
#include "gp32cmds.h"

unsigned char buffer[0x100];

struct file_info *fileinfo(const char* path) {
	signed int c=0,i=-1;
	struct file_info *data,*result=0;
	char* fullpath;
	
	fullpath=(char*)malloc(strlen(path) + 1);
	memcpy(fullpath,path,strlen(path)+1);
	while (c<(signed)strlen(fullpath)-1){
		if ((fullpath[c]=='/') || (fullpath[c]=='\\')) {
			i=c;
		}
		fullpath[c]=toupper(fullpath[c]);
		c++;
	}
	fullpath[c]=toupper(fullpath[c]);
	if (i>-1) {
	    fullpath[i]=0;
	    data=gp_dir(fullpath);
	} else {
	    data=gp_dir(NULL);
	}
	for(c=0; data[c].name; c++) {
		if (!strcmp(data[c].name,fullpath+1+i)) {
			result=(struct file_info*)malloc(sizeof(struct file_info));
			result->is_dir=data[c].is_dir;
			result->size=data[c].size;
			result->name=(char*)malloc(strlen(data[c].name)+1);
			strcpy(result->name,data[c].name);
		}
		free(data[c].name);
	}
	free(fullpath);
	free(data);
	return result;
}

/* convert unix-like paths to gp32 format */
/* obligation with the recipient to free the memory of
   the string. it always works as it's always a new
   string. */
char *mk_gppath(char *directory, int isdir) {
	int i=0,j;
	char *gppath;
	int path_length;


	if((directory==NULL) || (strlen(directory)==0)) {
		gppath=(char*)malloc(5);
		gppath[0]='g';
		gppath[1]='p';
		gppath[2]=':';
		gppath[3]='\\';
		gppath[4]='\0';
		return gppath;
	}

	j=((!isdir) || directory[strlen(directory)-1]=='\\' || directory[strlen(directory)-1]=='/')?0:1;

	if(!strncmp(directory, "gp:\\", 4)) {
		gppath=(char*)malloc(strlen(directory)+1+j);
		strcpy(gppath,directory);
		if (isdir) {
			gppath[strlen(gppath)+j]='\0';
			gppath[strlen(gppath)+j-1]='\\';
		}
		return gppath;
	}

	if(!strncmp(directory, "/", 1)) i=1;
	if(!strncmp(directory, "\\", 1)) i=1;

	path_length=(4+strlen(directory)+1-i+j);
	gppath=malloc(path_length+j);
	snprintf(gppath, path_length+j, "gp:\\%s%s", directory+i,(j==1)?"\\":"");
	for(i=0; gppath[i]; i++) {
		if(gppath[i]=='/') gppath[i]='\\';
	}
	return gppath;

}

int gp_connect() {
	return usb_connect();
}

void gp_disconnect() {
	usb_disconnect();
}

// return an array of file_info structs for the given dir
/* obligation with the recipient to free the struct file_info*
   and every ->name member of it */
struct file_info *gp_dir(char *directory) {
	unsigned char *gpdirectory;
	int result;
	int entry_size;
	struct file_info *dir_entries;
	int num_entries;
	int reading_directory;

	memset(buffer, 0, 0x100);
	*buffer=0x95;
	result=usb_write(buffer, 0x100);
	if(result==-1) return NULL;

	gpdirectory=mk_gppath(directory,1);

	memset(buffer, 0, 0x100);
	*buffer=strlen(gpdirectory);
	strncpy(buffer+1, gpdirectory, strlen(gpdirectory));
	result=usb_write(buffer, 0x100);
	free(gpdirectory); gpdirectory=0;
	if(result==-1) return NULL;

	dir_entries=calloc(2048, sizeof(struct file_info));
	reading_directory=1;
	num_entries=0;
	while(reading_directory) {
		result=usb_read(buffer, 0x100);
		if(result==-1) return NULL;
		if((*buffer)!=0x96) {
			reading_directory=0;
		} else {
			// get entry name
			entry_size=buffer[2];
			dir_entries[num_entries].name=malloc(entry_size+1);
			strncpy(dir_entries[num_entries].name, buffer+3, entry_size);
			dir_entries[num_entries].name[entry_size]='\0';
			// get entry type
			if(buffer[1]==1) { // entry is a directory
				dir_entries[num_entries].is_dir=1;
			} else { // entry is a file
				dir_entries[num_entries].is_dir=0;
			}

			// get entry size
			dir_entries[num_entries].size=(((unsigned int)*(buffer+3+entry_size+3)<<24)
				|((unsigned int)*(buffer+3+entry_size+2)<<16)
				|((unsigned int)*(buffer+3+entry_size+1)<<8)
				|((unsigned int)*(buffer+3+entry_size)));

			num_entries++;
			if(num_entries>=2047) {
				reading_directory=0;
			} else {
				memset(buffer, 0, 0x100);
				*buffer=0x3;
				result=usb_write(buffer, 0x100);
				if(result==-1) return NULL;
			}
		}
	}
	dir_entries[num_entries].name=NULL;
	return dir_entries;
}

int gp_end_link_mode() {
	int result;

	memset(buffer, 0, 0x100);
	*buffer=0x10;
	result=usb_write(buffer, 0x100);
	if(result==-1) {
		return -1;
	} else {
		return 0;
	}
}

/* it's the obligation of the recipient to free the memory it 
   gets the pointer to! */
struct smc_info *gp_info() {
	int result;
	struct smc_info *info;

	memset(buffer, 0, 0x100);
	*buffer=0x20;
	result=usb_write(buffer, 0x100);
	if(result==-1) return NULL;
	memset(buffer, 0, 0x100);
	result=usb_read(buffer, 0x100);
	if(result==-1) return NULL;
	info=malloc(sizeof(struct smc_info));
	info->capacity=(((unsigned int)*(buffer+4)<<24)
		|((unsigned int)*(buffer+3)<<16)
		|((unsigned int)*(buffer+2)<<8)
		|((unsigned int)*(buffer+1)));
	info->bytes_used=(((unsigned int)*(buffer+8)<<24)
		|((unsigned int)*(buffer+7)<<16)
		|((unsigned int)*(buffer+6)<<8)
		|((unsigned int)*(buffer+5)));
	info->bytes_free=(((unsigned int)*(buffer+12)<<24)
		|((unsigned int)*(buffer+11)<<16)
		|((unsigned int)*(buffer+10)<<8)
		|((unsigned int)*(buffer+9)));
	return info;
}

void gp_basename(char *name, char *bname83) {
	char *bname;
	char *dir;
	int i,j;
	int gotdot;
	int filename;
	
	/* send filename */
	bname = malloc(strlen(name)+1);
	strcpy(bname, name);
	bname = basename(bname);
	
	dir = (char*)calloc(strlen(name)+1, sizeof(char));
	strcpy(dir, name);
	dir = dirname(dir);
	/* convert to 8.3 filename format */

	/* convert spaces */
	for(i=0; bname[i]; i++) {
		if(bname[i]==' ') bname[i]='_';
	}

	/* lose any except the last dot */
	gotdot = 0;
	for(i = strlen(bname); i > 0; i--) {
		if(bname[i] == '.') {
			if(gotdot == 0) {
				gotdot = 1;
				if (i > 8){
					filename = 1;
				}
			} else {
				bname[i] = '_';
			}
		}
	}
	if(strlen(bname) > 12 || gotdot == 0 || filename == 1) {
		for(i = 0; i < 6; i++) {
			bname83[i] = bname[i];
		}
		bname83[i++] = 0x30 + (rand() % 10);
		bname83[i++] = 0x30 + (rand() % 10);
		for(j = 0; bname[j] != '.' && bname[j]; j++);
		while(bname[j])	bname83[i++] = bname[j++];
		bname83[i] = '\0';
	}else{
		memcpy(bname83, bname, strlen(bname) + 1);
	}
	strcat(dir, "/");
	strcat(dir, bname83);
	memcpy(bname83, dir, strlen(dir));
}

int gp_put_data(const char *srcdata, char *dst, const char* bname, unsigned int filesize) {
	int result;
	char *gppath;
	struct smc_info *info;
	unsigned int remaining, blocksize,done,progress;
	
printf("destino = %s, bname = %s, filesize = %d\n", dst, bname, filesize);
	/* check for enough free space */
	info=gp_info();
	if(info==NULL) {
		fprintf(stderr, "can't get smc info\n");
		return -1;
	}

	if(info->bytes_free<filesize) {
		fprintf(stderr, "not enough space on smc\n");
		return -1;
	}
	free(info); info=0;

	memset(buffer, 0, 0x100);
	*buffer=0xd0;
	result=usb_write(buffer, 0x100);
	if(result==-1) return -1;

	gppath=mk_gppath(dst,1);

	/* send destination directory */
	memset(buffer, 0, 0x100);
	*buffer=strlen(gppath);
	strcpy(buffer+1, gppath);
	result=usb_write(buffer, 0x100);
	free(gppath); gppath=0;
	if(result==-1) return -1;


	memset(buffer, 0, 0x100);
	result=usb_read(buffer, 0x100);
	if(result==-1) return -1;
	if(*buffer!=0xd1) return -1;

	memset(buffer, 0, 0x100);
	*buffer=strlen(bname);
	strcpy(buffer+1, bname);
	result=usb_write(buffer, 0x100);
	if(result==-1) return -1;

	memset(buffer, 0, 0x100);
	result=usb_read(buffer, 0x100);
	if(result==-1) return -1;
	if(*buffer!=0xd7) return -1;

	/* send filesize, TODO fix endianness? */
	memset(buffer, 0, 0x100);
	buffer[0]=(filesize&0x000000ff);
	buffer[1]=(filesize&0x0000ff00)>>8;
	buffer[2]=(filesize&0x00ff0000)>>16;
	buffer[3]=(filesize&0xff000000)>>24;
	result=usb_write(buffer, 0x100);
	if(result==-1) return -1;

	memset(buffer, 0, 0x100);
	result=usb_read(buffer, 0x100);
	if(result==-1) return -1;
	if(*buffer!=0xd2) return -1;

	progress=0;
	done=0;
	blocksize=0x100;
	remaining=filesize;
	while(remaining) {
		int fs;
		/* send block size */
		memset(buffer, 0, 0x100);
		fs=remaining>256*1024?256*1024:remaining;
		buffer[0]=(fs&0x000000ff);
		buffer[1]=(fs&0x0000ff00)>>8;
		buffer[2]=(fs&0x00ff0000)>>16;
		buffer[3]=(fs&0xff000000)>>24;
		result=usb_write(buffer, 0x100);
		if(result==-1) return -1;

		remaining-=fs;

		memset(buffer, 0, 0x100);
		result=usb_read(buffer, 0x100);
		if(result==-1) return -1;
		if(*buffer!=0xd3) return -1;

		/* send block */
		memset(buffer, 0, 0x100);
		while(fs>0 && memcpy(buffer, srcdata+done, blocksize)) {
			result=usb_write(buffer, 0x100);
			if(result==-1) return -1;
			memset(buffer, 0, 0x100);
			progress++;
			done+=blocksize;
			if (filesize-done<blocksize) blocksize=filesize-done;
			fs-=0x100;
		}

		/* expect d2 */
		memset(buffer, 0, 0x100);
		result=usb_read(buffer, 0x100);
		if(result==-1) return -1;
		if(*buffer!=0xd2) {
			fprintf(stderr, "expecting d2, got %x\n", *buffer);
			return -1;
		}
	}

	/* send 0, expect d4 */
	memset(buffer, 0, 0x100);
	result=usb_write(buffer, 0x100);
	if(result==-1) return -1;
	memset(buffer, 0, 0x100);
	result=usb_read(buffer, 0x100);
	if(result==-1) return -1;
	if(*buffer!=0xd4) return -1;

	return 0;
}

int gp_open(char *path, char *buf){
	int result;
	char *gppath;
	int filesize;
	int segmentsize;
	int bytes_read, total_bytes_read;
	int finished, segment_finished;
	int next_block_size;

	/* send cmd 70 */
	memset(buffer, 0, 0x100);
	*buffer=0x70;
	result=usb_write(buffer, 0x100);
	if(result==-1) return -1;

	gppath=mk_gppath(path,0);

	/* send file path */
	memset(buffer, 0, 0x100);
	*buffer=strlen(gppath);
	strcpy(buffer+1, gppath);
	result=usb_write(buffer, 0x100);
	free(gppath); gppath=0;
	if(result==-1) return -1;

	/* get file size */
	memset(buffer, 0, 0x100);
	result=usb_read(buffer, 0x100);
	if(result==-1) return -1;
	filesize=(((unsigned int)*(buffer+3)<<24)
		|((unsigned int)*(buffer+2)<<16)
		|((unsigned int)*(buffer+1)<<8)
		|((unsigned int)*(buffer)));

	finished=0;
	total_bytes_read=0;
	while(!finished) {
		/* get file segment size */
		memset(buffer, 0, 0x100);
		*buffer=0x71;
		result=usb_write(buffer, 0x100);
		if(result==-1) {
			return -1;
		}
		memset(buffer, 0, 0x100);
		result=usb_read(buffer, 0x100);
		if(result==-1) {
			return -1;
		}
		segmentsize=(((unsigned int)*(buffer+3)<<24)
			|((unsigned int)*(buffer+2)<<16)
			|((unsigned int)*(buffer+1)<<8)
			|((unsigned int)*(buffer)));
		
		/* request file data */
		memset(buffer, 0, 0x100);
		*buffer=0x72;
		result=usb_write(buffer, 0x100);
		if(result==-1) {
			return -1;
		}

		bytes_read=0;
		segment_finished=0;
		while(!segment_finished) {
			if((segmentsize-bytes_read)>0x100) {
				next_block_size=0x100;
			} else {
				next_block_size=segmentsize-bytes_read;
				segment_finished=1;
			}
			memset(buffer, 0, 0x100);
			result=usb_read(buffer, 0x100);
			if(result==-1) {
				return -1;
			}
			bytes_read+=next_block_size;
			memcpy(&buf[total_bytes_read], buffer, next_block_size);
			total_bytes_read+=next_block_size;
			
			if(total_bytes_read>=filesize) finished=1;
			if(!finished) {
				memset(buffer, 0, 0x100);
				*buffer=0x03;
				result=usb_write(buffer, 0x100);
				if(result==-1) {
					return -1;
				}
			}
		}
	}

	memset(buffer, 0, 0x100);
	*buffer=0x73;
	result=usb_write(buffer, 0x100);
	if(result==-1) return -1;
	
	return 0;
}

int gp_mkdir(char *path) {
	int result;
	char *gppath;

	/* send cmd a0 */
	memset(buffer, 0, 0x100);
	*buffer=0xa0;
	result=usb_write(buffer, 0x100);
	if(result==-1) return -1;

	gppath=mk_gppath(path,0);

	/* send file path */
	memset(buffer, 0, 0x100);
	*buffer=strlen(gppath);
	strcpy(buffer+1, gppath);
	result=usb_write(buffer, 0x100);
	free(gppath); gppath=0;
	if(result==-1) return -1;

	/* expect response a1 */
	memset(buffer, 0, 0x100);
	result=usb_read(buffer, 0x100);
	if(result==-1) return -1;
	if(*buffer!=0xa1) return -1;
	return 0;
}

int gp_rmdir(char *path) {
	int result;
	char *gppath;

	/* send cmd b0 */
	memset(buffer, 0, 0x100);
	*buffer=0xb0;
	result=usb_write(buffer, 0x100);
	if(result==-1) return -1;

	gppath=mk_gppath(path,1);

	/* send file path */
	memset(buffer, 0, 0x100);
	*buffer=strlen(gppath);
	strcpy(buffer+1, gppath);
	result=usb_write(buffer, 0x100);
	free(gppath); gppath=0;
	if(result==-1) return -1;

	/* expect response b1 */
	memset(buffer, 0, 0x100);
	result=usb_read(buffer, 0x100);
	if(result==-1) return -1;
	if(*buffer!=0xb1) return -1;
	return 0;
}

int gp_rm(char *path) {
	int result;
	char *gppath;

	struct file_info *test=fileinfo(path);
	if (!test) return -1; // file not found
	free(test->name); test->name=0;
	if (test->is_dir) {
		free(test);
		return -1;
	}
	free(test);

	/* send cmd c0 */
	memset(buffer, 0, 0x100);
	*buffer=0xc0;
	result=usb_write(buffer, 0x100);
	if(result==-1) return -1;

	gppath=mk_gppath(path,0);

	/* send file path */
	memset(buffer, 0, 0x100);
	*buffer=strlen(gppath);
	strcpy(buffer+1, gppath);
	result=usb_write(buffer, 0x100);
	free(gppath); gppath=0;
	if(result==-1) return -1;

	/* expect response c1 */
	memset(buffer, 0, 0x100);
	result=usb_read(buffer, 0x100);
	if(result==-1) return -1;
	if(*buffer!=0xc1) return -1;
	return 0;
}

int gp_format() {
	int result;

	memset(buffer, 0, 0x100);
	buffer[0] = 0x80;
	result=usb_write(buffer, 0x100);
	if (result==-1) return -1;

	result=usb_read(buffer, 0x100);
	if (result==-1) return -1;
	if (buffer[0] != 0x81) return -1;

	result=usb_read(buffer, 0x100);
	if (result==-1) return -1;
	if (buffer[0] != 0x82) return -1;

	return 0;
}

