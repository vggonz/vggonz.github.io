/*
 * gpfs: a virtual filesystem for accessing gp32
 * Copyright (C) 2004 Victor Garcia (vggonz@gmail.com)
 *
 * This program can be distributed under the terms of the
 * GNU GPL.
 * See the file LICENSE.
 */

#include <fuse.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <dirent.h>
#include <errno.h>
#include <time.h>
#include <sys/statfs.h>
#include <pthread.h>
#include <libgen.h>

#include "gp32cmds.h"

#define MOUNTPROG			"/usr/bin/fusermount"
#define GPFSPROG			"/usr/bin/gpfs"
#define MAX_FILES	1024		// Cantidad maxima de ficheros abiertos en memoria. 
					// Si se supera esta cantidad el resultado es impredecible
#define DBG(x...)// fprintf(stderr, x);	// Los mensajes de depuracion por la salida de errores

static int g_uid, g_gid, g_umask;	// Usuario, grupo y mascaras a aplicar a todos los elementos
static struct stat dir_st, file_st;	// Estructuras por defecto para los ficheros y directorios
static pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;	// Semaforo de acceso al dispositivo

// Estructura que representa a un fichero abierto
struct openfile{
	char* name;		// Path completo del fichero
	char* bname;		// Path completo con el nombre en formato 8.3
	int links;		// Numero de veces que se ha abierto
	int buffersize;		// Tamanyo del fichero en bytes
	char* bufferfile;	// Contenido del fichero
	int dirty;		// El contenido del fichero difiere con el fisico
};

static struct openfile *opened_files[MAX_FILES];

/*
 * Funcion que busca si un fichero ha sido abierto previamente
 * Recibe la ruta completa y devuelve un entero con la posicion que ocupa
 * en el array de ficheros abiertos. Si no se encuentra devuelve -1
 */
static int find_opened_file(char *path){
	int found = -1;
	int i = 0;
	while (found == -1 && i < MAX_FILES){
		if (opened_files[i] != NULL){
			// Se puede buscar el fichero por su nombre original si se acaba de escribir
			// o por su nombre en 8.3
			if (strcasecmp(opened_files[i]->name, path) == 0 || strcasecmp(opened_files[i]->bname, path) == 0){
				found = i;
			}
		}
		i++;
	}
	return found;
}

/*
 * Funcion que busca el primer hueco libre en el array de
 * ficheros abiertos.
 */
static int find_first_free_file(){
	int found = -1;
	int i = 0;
	while (found == -1 && i < MAX_FILES){
		if (opened_files[i] == NULL){
			found = i;
		}
		i++;
	}
	return found;
}

/*
 * Funcion que libera de memoria una posicion en el array
 * de ficheros abiertos.
 * Si la posicion es incorrecta o no hay ningun fichero abierto
 * en la posicion dada la funcion no hace nada.
 */
static void free_opened_file(int i){
	if (i < 0 || opened_files[i] == NULL){ return; }

	free(opened_files[i]->name);
	free(opened_files[i]->bname);
	free(opened_files[i]->bufferfile);
	free(opened_files[i]);
	opened_files[i] = NULL;
}

/*
 * Solicita acceso al dispositivo bloqueando el mutex
 */
static int get_mutex(){
	pthread_mutex_lock(&mutex);
	return 0;
}

/*
 * Libera el acceso al dispositivo liberando el mutex
 */
static void free_mutex(){
	pthread_mutex_unlock(&mutex);
}

/*
 * Funcion que devuelve el contenido de un directorio
 */
static int gpfs_getdir(const char *path, fuse_dirh_t h, fuse_dirfil_t filler){

	int i;
	struct file_info *directory_list;

	get_mutex();
	DBG("gpfs_getdir %s\n", path);
	directory_list = gp_dir((char*)path);

       	for(i=0; directory_list[i].name; i++) {
		if (filler(h, directory_list[i].name, directory_list[i].is_dir ? DT_DIR : DT_REG) != 0)
		break;
	        free(directory_list[i].name);
       	}
       	free(directory_list);

	filler(h, ".", DT_DIR);
	filler(h, "..", DT_DIR);
	free_mutex();	

	return 0;
}

/*
 * Funcion que rellena la estructura dada con los atributos del fichero
 * o directorio solicitado
 */
static int gpfs_getattr(const char *path, struct stat *stbuf){
	int i, pos;
	int found = 0;
	char *s, *newdir, *item, *bname;
	struct file_info *directory_list;

	//TODO: Cache de directorios
	get_mutex();
	// Caso especial para la raiz del arbol
	if (*path == '/' && *(path+1) == '\0') {
		*stbuf = dir_st;
		found = 1;
	}else{
		DBG("gpfs_getattr %s\n", path);
		newdir = strdup(path);
		s = strrchr(newdir, '/');
        	*s = '\0';
	        item = s+1;
        	s = (s == newdir) ? "/" : newdir;

		// Si el fichero ya ha sido abierto hay que buscar
		// sus atributos por su nombre 8.3
		pos = find_opened_file((char*)path);
		if (pos >= 0){
			bname = strdup(opened_files[pos]->bname);
			item = basename(bname);
		}

		directory_list = gp_dir(s);
        	for(i=0; directory_list[i].name; i++) {
                	if (strcasecmp(item, directory_list[i].name) == 0) {
				found = 1;
				*stbuf = directory_list[i].is_dir ? dir_st : file_st;
				stbuf->st_size = directory_list[i].size;
				stbuf->st_blocks = stbuf->st_size / 512;
			}
				
		        free(directory_list[i].name);
        	}
        	free(directory_list);
	}
	free_mutex();
	if (found == 0) return -ENOENT;
	return 0;
}

/*
 * Funcion que crea un directorio en la ruta dada
 */
static int gpfs_mkdir(const char *path, mode_t mode){
	int res = 0;
	
	get_mutex();
	DBG("gpfs_mkdir %s\n", path);	
	if (gp_mkdir((char*)path) < 0){
		res = -errno;
	}
	free_mutex();
	return res;
}

/*
 * Funcion que borra el fichero al que apunta la ruta dada
 */
static int gpfs_unlink(const char *path){
	int res = 0;

	get_mutex();
	DBG("gpfs_unlink %s\n", path);
	if (gp_rm((char*)path)  < 0){
		res = -errno;
	}
	// Al borrarlo hay que eliminarlo del array de ficheros abiertos
	free_opened_file(find_opened_file((char*)path));
	free_mutex();

	return res;
}

/*
 * Funcion que elimina el directorio dado. No es necesario que
 * el directorio se encuentre vacio para la operacion
 */
static int gpfs_rmdir(const char *path){

	int res = 0;

	get_mutex();
	DBG("gpfs_rmdir %s\n", path);	
	res = gp_rmdir((char*)path);
	free_mutex();

	return res;
}

/*
 * Funcion que abre un fichero y carga todo su contenido en memoria para
 * lecturas posteriores
 */
static int gpfs_open(const char *path, int flags){
	int i = 0;
	int res = 0;
	int pos;

	struct file_info *files;
	char *s, *newdir, *item, *bname;
	
	pos = find_opened_file((char*)path);
	if (pos >= 0){
		// Si ya se habia abierto solo se incrementa el contador
		DBG("gpfs_open %s ya abierto\n", path);
		opened_files[pos]->links++;
		return 0;
	}

	get_mutex();
	DBG("gpfs_open %s\n", path);	

	pos = find_first_free_file();
	
	switch (flags & O_ACCMODE) {
		case O_RDONLY:
			newdir = strdup(path);
			s = strrchr(newdir, '/');
			*s = '\0';
			item = s+1;
			s = (s == newdir) ? "/" : newdir;
			files = gp_dir(s);
			for(i=0; files[i].name; i++) {
		               	if (strcasecmp(item, files[i].name) == 0) {
					// Se crea la estructura en el array de ficheros abiertos
					opened_files[pos] = (struct openfile*)malloc(sizeof (struct openfile));
					opened_files[pos]->buffersize = files[i].size;
					opened_files[pos]->links = 1;
					opened_files[pos]->dirty = 0;
					opened_files[pos]->bufferfile = (char *)malloc(opened_files[pos]->buffersize);
					opened_files[pos]->name = (char*)calloc(strlen(path) + 1, sizeof(char));
					
					opened_files[pos]->bname = (char*)calloc(strlen(path) + 1, sizeof(char));
					gp_basename(path, opened_files[pos]->bname);
					
					memcpy(opened_files[pos]->name, path, strlen(path) + 1);
				}
			
			        free(files[i].name);
		        }
		        free(files);
			gp_open(path, opened_files[pos]->bufferfile);
			break;

//		case O_WRONLY://dbg("open O_WRONLY\n");
//			DBG("open O_WRONLY\n");
//			opened_files[pos]->buffersize = 0;
//			opened_files[pos]->links = 1;
//			opened_files[pos]->dirty = 1;
//			opened_files[pos]->bufferfile = (char *)malloc(0);
//			opened_files[pos]->name = (char*)malloc(strlen(path) + 1);
//			memcpy(opened_files[pos]->name, path, strlen(path) + 1);
//			gp_open(path, opened_files[pos]->bufferfile);
//			break;

		default:
			res = -EPERM;
			break;
	}
	free_mutex();
	return res;
}

/*
 * Funcion que cierra un fichero abierto. Al cerrar el fichero no se
 * elimina su contenido de memoria por si se vuelve a abrir en un futuro,
 * ya que la lectura del dispositivo es muy costosa.
 */
static int gpfs_close(const char *path, int flags) {
	
	char *dir;
	char *dir_aux;
	char *bname;
	char *bname_aux;
	int res = 0, pos;

	get_mutex();
	pos = find_opened_file((char*)path);
	DBG("gpfs_close %s\n", path);
	
	// Se decrementa el contador de veces que se ha abierto
	opened_files[pos]->links--;
	// Para evitar sobrecargar el bus, aunque un fichero se cierre no se elimina de
	// memoria por si se vuelve a acceder proximamente. Se liberaran completamente
	// todos los ficheros cuando se desmonte el dispositivo.
	// Si se manipulan muchos ficheros puede que se ocupe demasiada memoria pero
	// hubo que elegir entre tiempo o espacio, y elegi tiempo :). 
	// Ademas, como maximo solo se ocuparan 128 MB en memoria en el peor de los casos.
	if (opened_files[pos]->links <= 0) {
		// Si no usa nadie mas el fichero y ademas esta sucio se vuelva sobre el dispositivo
		if (opened_files[pos]->dirty == 1){
			
			dir_aux = (char*)calloc(strlen(path) + 1, sizeof(char));
			strcpy(dir_aux, path);
			dir = dirname((char*)dir_aux);
			
			opened_files[pos]->dirty = 0;
			bname_aux = strdup(opened_files[pos]->bname);
			bname = basename(bname_aux);
			res = gp_put_data(opened_files[pos]->bufferfile, dir, bname, opened_files[pos]->buffersize);

			free(bname_aux);
			free(dir_aux);
		}
		opened_files[pos]->links = 0;
//		free_opened_file(pos);
	}
	free_mutex();

	return res;
}

/*
 * Funcion que cambia de nombre un fichero.
 * Como no hay una primitiva de borrado en el protocolo hay que leer todo
 * el fichero antiguo, cambiarle el nombre, volverlo a escribir y borrar
 * el antiguo. Es una operacion muy lenta.
 */
static int gpfs_rename(const char *from, const char *to){
	
	int old, new;
	DBG("gpfs_rename de %s a %s\n", from, to);

	// Se lee el nombre antiguo
	gpfs_open(from, O_RDONLY);
	old = find_opened_file((char*)from);
	
	// Se crea el nuevo fichero con el nuevo nombre
	new = find_first_free_file();
	opened_files[new] = (struct openfile*)malloc(sizeof(struct openfile));
	
	opened_files[new]->name = (char*)calloc(strlen(to) + 1, sizeof(char));
	memcpy(opened_files[new]->name, to, strlen(to) + 1);
	opened_files[new]->bname = (char*)calloc(strlen(to) + 1, sizeof(char));
	gp_basename(to, opened_files[new]->bname);
	
	// Se copia su contenido
	opened_files[new]->buffersize = opened_files[old]->buffersize;
	opened_files[new]->bufferfile = (char *)malloc(opened_files[new]->buffersize);
	memcpy(opened_files[new]->bufferfile, opened_files[old]->bufferfile, opened_files[new]->buffersize);
	opened_files[new]->links = 1;
	opened_files[new]->dirty = 1;

	// Se cierran ambos ficheros provocando que el nuevo se vuelque al dispositivo
	gpfs_close(to, 0);
	gpfs_close(from, 0);
	// Se elimina el fichero con el nombre antiguo
	gpfs_unlink(from);
		
	return 0;
}

/*
 * Funcion que crea un fichero vacio
 */
static int gpfs_mknod(const char *path, mode_t mode, dev_t rdev){

	int pos;
	int res = 0;
	long t;
	DBG("gpfs_mknod %s\n", path);

	t = mode & S_IFMT;
	if (t != 0 && t != 0100000)
    	return -EPERM;

	// Al crearlo es como si se abriera y su contenido fuera vacio
	pos = find_first_free_file();
	opened_files[pos] = (struct openfile*)malloc(sizeof(struct openfile));
	opened_files[pos]->buffersize = 0;
	opened_files[pos]->links = 1;
	opened_files[pos]->dirty = 1;	// Se marca como sucio para que se refleje en el dispositivo
	opened_files[pos]->bufferfile = (char *)malloc(0);
	opened_files[pos]->name = (char*)calloc(strlen(path) + 1, sizeof(char));
	memcpy(opened_files[pos]->name, path, strlen(path) + 1);
	
	opened_files[pos]->bname = (char*)calloc(strlen(path) + 1, sizeof(char));
	gp_basename((char*)path, opened_files[pos]->bname);

	gpfs_close((char*)path, 0);
	
	return res;
}

/*
 * Funcion que trunca el contenido de un fichero a un tamanyo limite
 */
static int gpfs_truncate(const char *path, off_t size){
	int res = 0, pos;
	char *bufferfile;

//	get_mutex();
	DBG("gpfs_truncate %s a %d bytes\n", path, size);
	// Si se trunca a 0 bytes cuesta menos borrarlo y crearlo de nuevo vacio
	if (size == 0){
		pos = find_opened_file((char*)path);
		res = gpfs_unlink(opened_files[pos]->bname);
		res = gpfs_mknod(path, 33152, 0);	// TODO: Averiguar el nombre de la constante que genera ese numero
	}else{
		gpfs_open(path, O_RDONLY);		// Se abre para lectura
		pos = find_opened_file((char*)path);	// Se busca donde lo ha abierto
		opened_files[pos]->buffersize = size;	// Ajusta el nuevo tama�o
		bufferfile = (char*)malloc(size);	// Se genera un nuevo array para el fichero
		memcpy(bufferfile, opened_files[pos]->bufferfile, size);	// Copia lo que quepa al nuevo array
		free(opened_files[pos]->bufferfile);	// Libera el anterior array
		opened_files[pos]->bufferfile = bufferfile;	// Asociamos el nuevo array
		gpfs_close(path, 0);			// Cierra para que se hagan efectivos los cambios
	}
//	free_mutex();

    return res;
}

/*
 * Funcion que lee un fragmento del fichero. Recibe la posicion inicial y
 * la cantidad de bytes a partir de ella. Devuelve la cantidad de bytes que se
 * han podido leer satisfactoriamente que puede ser menor o igual a la cantidad
 * solicitada
 */
static int gpfs_read(const char *path, char *buf, size_t size, off_t offset){
	
	int n, position;
	int r=0;
	
	char* bufferfile;
	int pos = find_opened_file((char*)path);
	if (pos < 0) return -EBADF;
	DBG("gpfs_read %s %d bytes desde %d\n", path, size, offset);

	// Si se pide leer una cantidad mas alla del final del fichero se ajusta
	// a la cantidad restante hasta el final
	if ((offset + size) < opened_files[pos]->buffersize){
		n = size;
	}else{
		n = opened_files[pos]->buffersize - offset;
	}
	bufferfile = opened_files[pos]->bufferfile;
	// Como el fichero ya se leyo cuando se abrio, solo hace falta copiar el fragmento
	// pedido en el array
	memcpy(buf, &bufferfile[offset], n);
	
	return n;
}

/*
 * Funcion que escribe un fragmento del fichero. Recibe la posicion inicial y
 * la cantidad de bytes a partir de ella. Devuelve la cantidad de bytes que se
 * han podido escribir satisfactoriamente que sera igual a la cantidad pasada
 */
static int gpfs_write(const char *path, const char *buf, size_t size, off_t offset){

	char* bufferfile;
	int pos = find_opened_file((char*)path);
	if (pos < 0) return -EBADF;

	DBG("gpfs_write %s %d bytes desde %d\n", path, size, offset);
	opened_files[pos]->dirty = 1;	// Se marca como sucio para que se guarde su contenido al cerrar
	// Si el fragmento a escribir esta mas alla del limite del array, se crea una nuevo adecuado
	// al tamanyo, se copia el contenido anterior y finalmente se anyade el nuevo fragmento
	if (offset + size > opened_files[pos]->buffersize){
		bufferfile = (char*)malloc(offset + size);
		memcpy(bufferfile, opened_files[pos]->bufferfile, opened_files[pos]->buffersize);
		opened_files[pos]->buffersize = offset + size;
		free(opened_files[pos]->bufferfile);
		opened_files[pos]->bufferfile = bufferfile;
	}
	memcpy(&opened_files[pos]->bufferfile[offset], buf, size);
	return size;
}

/*
 * Funcion que rellena la estructura dada con las propiedades del dispositivo
 * como bytes ocupados, tamanyo total y espacio libre restante
 */
static int gpfs_statfs(struct fuse_statfs *fst){
	struct smc_info *info;
				
	get_mutex();
	bzero(fst, sizeof(struct fuse_statfs));
	info=gp_info();

	if (info != NULL){
		fst->block_size = 512;
		fst->blocks = info->capacity / 512;
		fst->blocks_free = info->bytes_free / 512;
		fst->namelen = 255;
	}
	free_mutex();

	return 0;
}

/*
 * Operacion del sistema de archivos que se han implementado.
 * No se encuentran todas las relacionadas con permisos y tiempo
 * ya que no las soporta la unidad.
 */
static struct fuse_operations gpfs_oper = {
    getattr:		gpfs_getattr,
    getdir:    		gpfs_getdir,
    mknod:		gpfs_mknod,
    mkdir:		gpfs_mkdir,
    unlink:		gpfs_unlink,
    rmdir:		gpfs_rmdir,
    rename:		gpfs_rename,
    truncate:		gpfs_truncate, 
    open:		gpfs_open,
    read:		gpfs_read,
    write:		gpfs_write,
    release:		gpfs_close,
    statfs:		gpfs_statfs,
};

/*
 * Funcion que muestra el uso del programa
 */
void usage() {

	fprintf(stderr, "Usage: mount -t gpfs [-o options] mountpoint\n\n");
	fprintf(stderr, "Options:\n");
	fprintf(stderr, "\tuid=<value>\t\towner id\n");
	fprintf(stderr, "\tgid=<value>\t\tgroup id\n");
	fprintf(stderr, "\tumask=<value>\t\tumask value (octal)\n");
	exit(1);
}

/*
 * Operaciones a realizar al terminar el programa
 */
void cleanup() {
	gp_end_link_mode();
}

/*
 * Funcion principal
 */
int main(int argc, char *argv[]){
	char *mountprog = MOUNTPROG;
	char *gpfsprog = GPFSPROG;
	char **fuse_argv = (char **) malloc(3 + argc + 1);
	char *p, *pp;
	int i, j, fuse_argc;
	pid_t pid;

	p = strrchr(argv[0], '/');
	p = (p == NULL) ? argv[0] : p+1;

	if (strncmp(p, "mount", 5) == 0) {
		fuse_argc = 0;
		fuse_argv[fuse_argc++] = mountprog;
		if (getuid() == 0){
			fuse_argv[fuse_argc++] = "-x";
		}
		fuse_argv[fuse_argc++] = argv[2];
		fuse_argv[fuse_argc++] = gpfsprog;
		fuse_argv[fuse_argc++] = argv[1];
		for (j = 4; j < argc; j++){
			fuse_argv[fuse_argc++] = argv[j];
		}

		execvp(mountprog, fuse_argv);
	}else{	
		fuse_argc = argc;
		fuse_argv = argv;
	}

	if (argc < 2){
		usage();
	}

	g_uid = getuid();
	g_gid = getgid();
	g_umask = umask(0);
	umask(g_umask);

	if (argc >= 3) {
		p = argv[2];
		while (p && *p) {
			if (strncmp(p, "uid=", 4) == 0) {
				g_uid = atoi(p+4);
			} else if (strncmp(p, "gid=", 4) == 0) {
				g_gid = atoi(p+4);
			} else if (strncmp(p, "umask=", 6) == 0) {
				g_umask = strtol(p+6, NULL, 8);
			}
				
			p = strchr(p, ',');
			if (p) p++;
		}
	}

	bzero(&dir_st, sizeof(dir_st));
	bzero(&file_st, sizeof(file_st));
	dir_st.st_nlink = file_st.st_nlink = 1;
	dir_st.st_blksize = file_st.st_blksize = 512;
	dir_st.st_mode = 0040777 & ~g_umask;
	file_st.st_mode = 0100666 & ~g_umask;
	dir_st.st_uid = file_st.st_uid = g_uid;
	dir_st.st_gid = file_st.st_gid = g_gid;
	//dir_st.st_(a/m/c)time = gettimeofday.tv_sec
	//igual para los ficheros file_st

        if(gp_connect()==-1) {
        	perror("gpfs: gp connection error\n");
        	exit(1);
        }

	pid = fork();
	if (pid < 0){
		perror("fork");
		exit(1);
	}else if (pid != 0){
		// padre
		usleep(200000);
		return 0;
	}
	// hijo
	setsid();

	atexit(cleanup);

	if (strncmp(fuse_argv[1], "/proc", 5) == 0) fuse_argc = 1;
	fuse_main(fuse_argc, fuse_argv, &gpfs_oper);

	// Se liberan de memoria todos los ficheros abiertos durante la sesion.
	// No se liberan cuando se cierran para evitar volver a leer del dispositivo
	// que es muy lento.
	for (i = 0; i < MAX_FILES; i++){
		free_opened_file(i);
	}
	return 0;
}
