
int usb_connect();

void usb_disconnect();

int usb_read(char *buffer, int buffer_size);

int usb_write(char *buffer, int buffer_size);

